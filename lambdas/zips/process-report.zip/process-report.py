import json
import boto3
import sys
import os

print('Loading function')


def lambda_handler(event, context):

    athena = boto3.client('athena')

    try:
        #get the named queries

    except Exception as (e):


    # aws athena batch-get-named-query --named-query-ids "" "" "" ""
